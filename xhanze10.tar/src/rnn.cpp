class LSTM
