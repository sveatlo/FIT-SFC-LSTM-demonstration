# LSTM network demonstration
This is a simple LSTM NN implmentation using C++. It was created as part of a school assignment in the SFC cource at FIT BUT.
